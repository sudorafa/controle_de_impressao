<?php

	$nome			= $_GET["nnome"];
	$matricula		= $_GET["nmat"];
	$setor			= $_GET["nsetor"];
	$email			= $_GET["nemail"];
	$sexo			= $_GET["nsex"];
	$grauUrgencia	= $_GET["ngrau"];
	$mensagem		= $_GET["mensagem"];

echo "Nome " .$nome."<br/>Matricula: ".$matricula;



?>