<?php 
	$conexao = mysql_connect("localhost","root","usbw");
	mysql_select_db("controleimpressao")
 ?>