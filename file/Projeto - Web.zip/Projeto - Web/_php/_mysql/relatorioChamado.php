<link rel="stylesheet" href="../../_css/estilo_php.css">
<?php

echo "<h2>Esta pesquisa está em desenvolvimento!</h2>";
echo "<a href='../../_iframes/formrelatorio.html#chamado'><img id='refresh' src='../../_imagens/_botoes/refresh1.png'></a>";
?>