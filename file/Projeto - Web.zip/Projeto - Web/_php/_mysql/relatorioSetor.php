<link rel="stylesheet" href="../../_css/estilo_php.css">
<?php

echo "<h2>Esta pesquisa está desativada!</h2>";
echo "<a href='../../_iframes/formrelatorio.html#setor'><img id='refresh' src='../../_imagens/_botoes/refresh1.png'></a>";
?>