<?php

phpinfo(); 

?>